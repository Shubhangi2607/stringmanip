/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<cstring>
#include<bits/stdc++.h>
using namespace std;

int main()
{int choice=0;
    cout<<"enter choice";
    cin>>choice;
switch(choice)
{
    case 1:
    {string str;
        cout<<"enter string";
        cin>>str;
        cout<<str.size();
    }
    case 2:
    {int i=0;
     char str1[100];  char str2[100];
    cout<<"enter string";
    cin>>str1;
       
        for(i=0;i<strlen(str1);i++)
        {
            str2[i]=str1[i];
        }
        str2[i]='\0';
      
        
         cout<<str2;
    }
    case 3:
    {
        int i=0;
     char str1[100];  char str2[100];
    cout<<"enter string";
    cin>>str1;
    cout<<"enter string";
    cin>>str2;
      strcat(str1,str2);
      
        
         cout<<str1;
    }
    
    case 4:
    {
         char str1[100];  char str2[100];
    cout<<"enter string";
    cin>>str1;
    cout<<"enter string";
    cin>>str2;
    int x=strcmp(str1,str2);
    if(x==0)
    {
        cout<<"equal";
    }
    else if(x>0)
    {
        cout<<"str1 is greater";
    }
    else 
    {
        cout<<"str2 is greater";
    }
    }
    case 5:
    {
         char str1[100];  char str2[100];
    cout<<"enter string";
    cin>>str1;
    int n= strlen(str1);
  while(n!=0)
  {
      cout<<str1[n];
      n--;
  }
  cout<<str1[n];
    }
    

 case 6:
    {
         char str1[100];  char str2[100];
    cout<<"enter string";
    cin>>str1;
    int n= strlen(str1);
  for(int i=0;i<n;i++)
  {
      if(isupper(str1[i]))
      {
      str1[i]=tolower(str1[i]);
      cout<<str1[i];
      }
      else if(islower(str1[i]))
      {
          str1[i]=toupper(str1[i]);
          cout<<str1[i];
      }
     
  }
 
    }
    
}

    return 0;
}

